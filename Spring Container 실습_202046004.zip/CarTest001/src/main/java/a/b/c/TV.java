package a.b.c;

public interface TV {
	public void turnOn();
	
}
