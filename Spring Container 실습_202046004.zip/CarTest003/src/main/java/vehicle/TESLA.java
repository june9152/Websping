package vehicle;

public class TESLA implements Car {

	@Override
	public void �õ�(Engine engine) {
		// TODO Auto-generated method stub
		System.out.println("[TESLA]");
//		ElectricEngine engine = new ElectricEngine();
		engine.�õ�();
	}

	@Override
	public void ����(Engine engine) {
		// TODO Auto-generated method stub
		System.out.println("[TESLA]");
//		ElectricEngine engine = new ElectricEngine();
		engine.����();
	}

	@Override
	public void ����() {
		// TODO Auto-generated method stub
		System.out.println("[TESLA]---�����Ѵ�.");
	}

}
