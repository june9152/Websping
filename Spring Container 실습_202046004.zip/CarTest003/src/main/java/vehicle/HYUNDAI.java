package vehicle;

public class HYUNDAI implements Car {

	@Override
	public void �õ�(Engine engine) {
		// TODO Auto-generated method stub
		System.out.println("[Hyundai]");
//		GasolineEngine engine = new GasolineEngine();
		engine.�õ�();
	}

	@Override
	public void ����(Engine engine) {
		// TODO Auto-generated method stub
		System.out.println("[Hyundai]");
//		GasolineEngine engine = new GasolineEngine();
		engine.����();
	}

	@Override
	public void ����() {
		// TODO Auto-generated method stub
		System.out.println("[Hyundai]");
	}

}
